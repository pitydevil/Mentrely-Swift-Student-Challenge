import SwiftUI
import UIKit

extension UIView {
    func constraintWith(identifier: String) -> NSLayoutConstraint?{
           return self.constraints.first(where: {$0.identifier == identifier})
    }
    
    func setShadow() {
        self.layer.shadowOpacity = 0.35
        self.layer.shadowRadius  = 5.0
        self.layer.shadowColor   = UIColor(red:0/255.0, green:0/255.0, blue:0/255.0, alpha: 1.0).cgColor
        self.layer.shadowOffset  = CGSize(width: 0.0, height: 10)
    }
    
    
    func setLighterShadow() {
        self.layer.shadowOpacity = 0.30
        self.layer.shadowRadius  = 3.0
        self.layer.shadowColor   = UIColor(red:0/255.0, green:0/255.0, blue:0/255.0, alpha: 1.0).cgColor
        self.layer.shadowOffset  = CGSize(width: 0.0, height: 8)
    }
    
    func setLeftCorner() {
        self.layer.cornerCurve = .continuous
        self.layer.cornerRadius  = 20
        self.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMinXMinYCorner]
    }
}

extension UIButton {
    func setRightCorner() {
        self.layer.cornerCurve = .continuous
        self.layer.cornerRadius  = 20
        self.layer.shadowOpacity = 0.35
        self.layer.shadowRadius  = 3.0
        self.layer.shadowColor   = UIColor(red:0/255.0, green:0/255.0, blue:0/255.0, alpha: 1.0).cgColor
        self.layer.shadowOffset  = CGSize(width: 0.0, height: 5)
        self.layer.masksToBounds = false
        self.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMaxXMinYCorner]
    }
    func setRoundedCorner() {
        self.layer.cornerCurve = .continuous
        self.layer.cornerRadius  = 20
    }
}
