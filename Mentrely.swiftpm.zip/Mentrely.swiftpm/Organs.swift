//
//  File.swift
//  Mentrely
//
//  Created by Mikhael Adiputra on 22/04/22.
//

import UIKit

struct Organs {
    public var image       = UIImage()
    public var description = String()
    public var titleOrgan  = String()
}
