import SwiftUI

struct ContentView: View {
    var body: some View {
        MainUI()
    }
}

struct MainUI : UIViewControllerRepresentable {
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
        
    }
    func makeUIViewController(context: Context) -> some UIViewController {
        return MainViewController()
    }
}

class MainViewController : UIViewController {
    
    enum illnessType {
        case depression, anxiety, ptsd, bipolar, panic, mainMenu
    }
    
    private var illnessList = [[Organs]]()
    private var indexSelected   = -1
    private var organIndex      = -1
    private var illnessTypeVar  = illnessType.mainMenu
    private var introTitleText  = "Introduction"
    private var introText       = "Hi There!, Welcome to Mentrely!\n\nThis application was intended for kids and people who doesn't know about mental illness.\nThis app will provide the neccessary information for each illness, and will recommend the user the solution as well, since mental health illness is a serious topic, this application will still encourage user to seek out medical attention if their condition has progressed to a severe condition.\n\nI hope by creating this app, it can increase mental health awareness in Indonesia, since in my country alone, many of the information regarding issues are really hard to come by, many people doesn't know a thing about mental health illness.\n\nEven for those individual who's brave enough to seek out medical attention. They often get mocked by their family and peers.\nMaybe in the future, I'll try to implement medical assistance API, connect the application with a nearby hospital, etc.\n\nThat's All :), Thanks for the opportunity guys!"
    
    lazy var depressionButton: UIButton! = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(responseButton(_:)), for: .touchUpInside)
        button.tag = 0
        button.backgroundColor = .red
        button.titleLabel?.font = UIFont(name: "Jua-Regular", size: 26)
        button.setTitle("Depression", for: .normal)
        button.contentEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.configuration = nil
        button.setRightCorner()
     
        return button
        
      }()
    
    lazy var anxietyButton: UIButton! = {
        
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(responseButton(_:)), for: .touchUpInside)
        button.tag = 1
        button.backgroundColor = UIColor(red: 102.0/255.0, green: 216.0/255.0, blue: 161.0/255.0, alpha: 1.0)
        button.setTitle("Anxiety", for: .normal)
        button.titleLabel?.font = UIFont(name: "Jua-Regular", size: 26)
        button.contentEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.configuration = nil
        button.setRightCorner()
     
        return button
        
      }()
    
    lazy var ptsdButton: UIButton! = {
        
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(responseButton(_:)), for: .touchUpInside)
        button.tag = 2
        button.backgroundColor = UIColor(red: 85.0/255.0, green: 163.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        button.setTitle("PTSD", for: .normal)
        button.titleLabel?.font = UIFont(name: "Jua-Regular", size: 26)
        button.contentEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.configuration = nil
        button.setRightCorner()
     
        return button
        
      }()
    
    lazy var bipolarButton: UIButton! = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(responseButton(_:)), for: .touchUpInside)
        button.tag = 3
        button.backgroundColor = UIColor( red: 173.0/255.0, green: 90.0/255.0, blue: 239.0/255.0, alpha: 1.0)
        button.setTitle("Bipolar", for: .normal)
        button.titleLabel?.font = UIFont(name: "Jua-Regular", size: 26)
        button.configuration = nil
        button.contentEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.setRightCorner()
        return button
      }()
    
    lazy var panicButton: UIButton! = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(responseButton(_:)), for: .touchUpInside)
        button.tag = 4
        button.backgroundColor = .black
        button.setTitle("Panic", for: .normal)
        button.titleLabel?.font = UIFont(name: "Jua-Regular", size: 26)
        button.configuration = nil
        button.contentEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        button.setRightCorner()
        return button
      }()

    lazy var backButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(responseButton(_:)), for: .touchUpInside)
        button.tag = 5
        button.backgroundColor = UIColor(red: 74.0/255.0, green: 152.0/255.0, blue: 225.0/255.0, alpha: 1.0)
        button.setTitle("<", for: .normal)
        button.contentEdgeInsets = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        button.layer.cornerRadius = 20
        button.isEnabled = false
        button.alpha = 0
        button.setRoundedCorner()
        return button
    }()
    
    lazy var bodyImage: UIImageView! = {
        let theImageView = UIImageView()
        theImageView.image = UIImage(named: "fullBody.png")
        theImageView.translatesAutoresizingMaskIntoConstraints = false
        theImageView.contentMode = .scaleAspectFill
        theImageView.clipsToBounds = false
        theImageView.setShadow()
        return theImageView
    }()
    
    lazy var organImage: UIImageView! = {
        let theImageView = UIImageView()
        theImageView.image = UIImage(named: "lungs.png")
        theImageView.translatesAutoresizingMaskIntoConstraints = false
        theImageView.contentMode = .scaleAspectFit
        theImageView.clipsToBounds = true
        return theImageView
    }()
    
    
    lazy var leftView : UIView! = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var middleView : UIView! = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var rightView : UIView! = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var containerView : UIView! = {
        let view = UIView()
        view.backgroundColor = UIColor(red: 255.0/255.0, green: 248.0/255.0, blue: 185.0/255.0, alpha: 1.0)
        view.setLighterShadow()
        view.setLeftCorner()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = introTitleText
        label.font = UIFont(name: "Jua-Regular", size: 30)
        label.textColor = .black
        return label
    }()
    
   
    lazy var mentrelyLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Mentrely"
        label.font = UIFont(name: "Grandstander-Bold", size: 64)
        label.textColor = UIColor(red: 74.0/255.0, green: 152.0/255.0, blue: 225.0/255.0, alpha: 1.0)
        return label
    }()
    
    lazy var descTextView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.backgroundColor = .clear
        textView.textColor = .black.withAlphaComponent(0.6)
        textView.backgroundColor = .clear
        textView.font = UIFont(name: "Jua-Regular", size: 24)
        textView.text = introText
        textView.isEditable = false
        textView.showsHorizontalScrollIndicator = false
        textView.showsVerticalScrollIndicator   = true
        return textView
    }()
    
    lazy var pageControl: UIPageControl = {
        let pageControl = UIPageControl()
        pageControl.translatesAutoresizingMaskIntoConstraints = false
        pageControl.isUserInteractionEnabled = false
        pageControl.pageIndicatorTintColor = .lightGray
        pageControl.currentPageIndicatorTintColor = .darkGray
        pageControl.alpha = 0
        return pageControl
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        createDatabase()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let cfURL = Bundle.main.url(forResource: "Jua-Regular", withExtension: "ttf")! as CFURL
        let cf2URL = Bundle.main.url(forResource: "Grandstander-Bold", withExtension: "ttf")! as CFURL
        CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
        CTFontManagerRegisterFontsForURL(cf2URL, CTFontManagerScope.process, nil)
        setConstraint()

    }
    
    private func createDatabase() {
        
        var brainOrganArray = [Organs]()
        
        let dOrgan0 = Organs(image: UIImage(named: "brain")!, description: "Depression (major depressive disorder) is a common and serious medical illness that negatively affects how you feel, the way you think and how you act.\n\nFortunately, it is also treatable. Depression causes feelings of sadness and/or a loss of interest in activities you once enjoyed. It can lead to a variety of emotional and physical problems and can decrease your ability to function at work and at home.", titleOrgan: "Depression")
        let dOrgan1 = Organs(image: UIImage(named: "brain")!, description: "Depression cause the individual to suffer Insomnia, and massive headache. It was due to the amount of stress and negativity that resides in the individual feeling.", titleOrgan: "Brain")
     
        let dOrgan2 = Organs(image: UIImage(named: "stomach")!, description: "It's also common for individual to suffer stomach ache that also cause nausea and weight loss.", titleOrgan: "Stomach")
      
        let dOrgan3 = Organs(image: UIImage(named: "fullIntestines")!, description: "This particular illness can also cause some individual to develop diarrhea and constipation, some of them even developed a bowel syndrom, it was known as IBS or Irritable Bowel Syndrome.", titleOrgan: "Intestines")
        
        let dOrgan4 = Organs(image: UIImage(named: "fullIntestines")!, description: "There are several solution to overcome depression, although it's still best to get professional help if the illness continue to get worsen or has already been on the latent state.\n\n\u{2022} Get Some Excercise\n  Taking a short walk each day, doing ten minutes of calisthenics at home, or putting on some music and dancing are all suitable types of exercise for reducing depression.Exercise helps with the symptoms of depression because it increases brain chemicals called endorphins. Even a few minutes a day of mild exercise can improve mood by elevating endorphin levels.\n\n\u{2022} Challenge Negative Thoughts\n It's often for someone who's depressed to engage in negative thinking, these thoughts such as I'm a Failure, No one likes me or I'll always feel this way are pretty common in a depressed person's mind. \n A simple solution to this problem is to challenge negative thoughts with positive thinking. You can try to think about a time when you did feel differently about life \n\n\u{2022} Get Adequate Sleep \nDepression can contribute to insomnia, which could lead to difficulty in falling and staying asleep. Making changes in your routine may help with getting a more restful sleep throughout the night.", titleOrgan: "Solution")
        
        brainOrganArray.append(dOrgan0)
        brainOrganArray.append(dOrgan1)
        brainOrganArray.append(dOrgan2)
        brainOrganArray.append(dOrgan3)
        brainOrganArray.append(dOrgan4)
        
        illnessList.append(brainOrganArray)

        var anxietyOrganList = [Organs]()
        let diagnostic = Organs(image: UIImage(named: "brain")!, description: "Anxiety is human's body natural response to stress, it's a feeling of fear or apprehension about what will come. If a feeling of anxiety has become extreme and it last longers than six months it's possible that the individual has developed anxiety disorder\n\nSo what's anxiety disorder?\n\nIn simple term anxiety disorder is a mental illness in which a person is so anxious that their normal life is affected. \n\nHere's a list of comprehension which organs was affected by this illness.", titleOrgan: "Anxiety Disorder")
        anxietyOrganList.append(diagnostic)
        let brainOrgan = Organs(image: UIImage(named: "brain")!, description: "Anxiety cause the individual to worry about everything where it can lead to the increase of your overall feelings of irritability.\n\nTherefore it's also not common for individual to also suffer headache from the constant worry.", titleOrgan: "Brain")
        anxietyOrganList.append(brainOrgan)
        
        let lungsOrgans = Organs(image: UIImage(named: "lungs")!, description: "Breathing problem is also another common symptomps for anxiety individual, it can cause the individual to have rapid, shallow breathing.\n\nThese symptoms will get worse if the user suffer panic attack at the same time", titleOrgan: "Lungs")
        anxietyOrganList.append(lungsOrgans)
        let stomachOrgans = Organs(image: UIImage(named: "stomach")!, description: "Stomach is also affected by this illness, stomach pains may be accompanied by severe diarrhea and nausea", titleOrgan: "Stomach")
        anxietyOrganList.append(stomachOrgans)
        let solutionAnxiety = Organs(image: UIImage(named: "stomach")!, description: "There are several ways to lessen anxiety disorder effect, these solutions will only work if the individual anxiety hasn't progressed to the severe case, if so please get professional help as soon as possible.\n\nHere's the known working solution:\n\n\u{2022} Get Enough Sleep\n\n\u{2022} Meditating\n\n\u{2022} Avoiding Alcohol, cafeine altogether\n\n\u{2022} Working out and daily excercise\n", titleOrgan: "Solution")
        anxietyOrganList.append(solutionAnxiety)
        
        illnessList.append(anxietyOrganList)
        
        var ptsdOrganList = [Organs]()
        
        let ptsdOrganDiagnostic = Organs(image: UIImage(named: "brain")!, description: "PTSD is a psychiatric disorder that may occur in people who have experienced a traumatic even such us an accident, a natural disaster or who have been threatened with death.\n\nThere are several ways to diagnose PTSD, the individual doctor will likely\n\n\u{2022} Perform a physical exam\n\n\u{2022} Do a psychological evaluation\n\nHere's a list of organs that's affected by this illness.", titleOrgan: "PTSD")
        ptsdOrganList.append(ptsdOrganDiagnostic)
        let brainOrganPTSD = Organs(image: UIImage(named: "brain")!, description: "PTSD cause the brain to re-experiencing the traumatic event through intrusive memories, flashback, or recurrent dreams or nightmare.", titleOrgan: "Brain")
        ptsdOrganList.append(brainOrganPTSD)
        
        let lungsOrganPTSD = Organs(image: UIImage(named: "lungs")!, description: "Fast Breathing may happen to some individual when the individual reexperiencing the traumatic event.", titleOrgan: "Lungs")
        ptsdOrganList.append(lungsOrganPTSD)
        
        let liverOrganPTSD = Organs(image: UIImage(named: "hati")!, description: "Liver was also affected by this illness, the brain demanded the liver to convert glycogen to glucose more than the individual daily needs, it was due to the extra amount of the stress so the body feels the extra glucose is needed.", titleOrgan: "Liver")
        ptsdOrganList.append(liverOrganPTSD)
        
        let stomachOrganPTSD = Organs(image: UIImage(named: "stomach")!, description: "Slow disgetion may occur on the individual stomach, it might cause mild stomach-ache, and nausea on some individuals. If it wasn't treated properly, the stomach ache can progress into a dangerous bowel syndrome called IBS / (Irritable Bowel Syndrome).", titleOrgan: "Stomach")
        
        let ptsdSolution = Organs(image:  UIImage(named: "stomach")!, description:  "There are several methods to cope with this condition, but before doing so please remember that PTSD require professional medical attention.\n\n Here are the several method that the individual can try to do:\n\n\u{2022} Meditate\n\n With meditation, you can learn to be more mindful and aware of the present moment. When practicing mindfulness, you can become more cognizant of bodily sensations thoughts and fealing and learn about PTSD triggeres.\n\n\u{2022} Get a Service Dog\n\nPTSD service dogs can offer companionship and a calming effect for people with PTSD.\n\n\u{2022}Set Boundaries\n\nFamilies and friends can be impacted by a single person's struggle with PTSD. When someone is exposed to a traumatic event such as sexual assault or a natural disaster, their boundaries and sense of safety are violated. In relationships with friends, family or a significant other, it's therefore necessary to discuss PTSD triggers and ask loved to respect when space or time alone is needed.", titleOrgan: "Solution")
        
        ptsdOrganList.append(stomachOrganPTSD)
        ptsdOrganList.append(ptsdSolution)
        
        illnessList.append(ptsdOrganList)
        
        var bipolarOrganList = [Organs]()
        
        let bipolarDesc   = Organs(image:UIImage(named: "brain")!, description: "Bipolar disorder is known as manic depression, it's a brain based disorder where the condition is characterized by one or more occurences of manic episodes, and in some cases.\nIt may include a major depressive episode.\n\nThe disorder has the potential to affect virtually all other ares of the individual body, ranging from the individual energy level even to the appetite to your muscles and individual libido.\n\nThere are several ways to determine if someone has a bipolar disorder, the evaluation may include:\n\n\u{2022} Physical Exam\n\nYour doctor may do a physical exam and lab tests to identify any medical problems that could be causing your symptoms\n\n\u{2022}Physiatric Assessment\n\nYour doctor may refer to you to psyhiatrist, who will talk to the individual about the individual thoughts, feelings, and behavior patterns.\n\nHere's a list of organs that's affected by this illness.", titleOrgan: "Bipolar Disorder")
        
        bipolarOrganList.append(bipolarDesc)
        let brainBipolarOrgan = Organs(image: UIImage(named: "brain")!, description: "It's common for the individual to suffer fatigue loss, one the manic episode ends you may feel sleepier than normal.\n\nThis symptom also increase the risk of severe irritability, it's often associated with many mental health disorder and is often seen in bipolar disorder.\nAs the illness continue to get worsen, the individual may also develop extreme sadness where the individual can feel sadness, hopelessness, and extreme guilt.", titleOrgan: "Brain")
        bipolarOrganList.append(brainBipolarOrgan)
        
        let lungsBipolarOrgan = Organs(image: UIImage(named: "lungs")!, description: "Some people with bipolar disorder can have a co-occurring anxiety disorder. If bipolar disorder is accompanied with another illness it can cause breathing difficulties.\n\nEspecially if you have experience severe anxiety.", titleOrgan: "Lungs")
        bipolarOrganList.append(lungsBipolarOrgan)
        let stomachBipolarOrgan = Organs(image: UIImage(named: "stomach")!, description: "Bipolar disorder can make individual weight to fluctuate, either leading to losses or gain in weight.", titleOrgan: "Stomach")
        bipolarOrganList.append(stomachBipolarOrgan)
        
        let bipolarSolutionList = Organs(image:  UIImage(named: "stomach")!, description: "Unfortunately for this particular mental illness, there is no self help treatment to overcome this illness, it's better for the individual to seek professional mental health.\n\nThere are different type of drugs that can be used to ease out the symptoms such as Mood Stabilizer, Antipsychotics, and Antidepressants.", titleOrgan: "Solution")
        bipolarOrganList.append(bipolarSolutionList)
        
        illnessList.append(bipolarOrganList)
        
        var panicOrganArray = [Organs]()
        
        let panicDesc  = Organs(image: UIImage(named: "brain")!, description: "Panic Attack can be a debilitating even, so extreme that the individual may believe they're suffering from something worse than an anxiety disorder. This panic attack often mimic very serious health problem. Thousand of people are hospitalized each year after having a severe panic attack.\n\nHere's a list of organs that's affected by this illness", titleOrgan: "Panic Attack")
        panicOrganArray.append(panicDesc)
        let brainOrganPanic = Organs(image: UIImage(named: "brain")!, description: "Dizziness may occur when individual suffers panic attack, it often come with fear of losing control or dying.", titleOrgan: "Brain")
        panicOrganArray.append(brainOrganPanic)
        
        let lungsOrganPanic = Organs(image: UIImage(named: "lungs")!, description: "Hyperventilation is commonly associated with panic attacks. it may be caused by breathing too quickly, too deeply when panic attack happens.", titleOrgan: "Lungs")
        panicOrganArray.append(lungsOrganPanic)
        
        let stomachOrganPanic = Organs(image: UIImage(named: "stomach")!, description: "Feeling of nausea or abdominal stress may also occur when panic attack happens, this symptom can be really bad if it wasn't treated properly.", titleOrgan: "Stomach")
        panicOrganArray.append(stomachOrganPanic)
        
        let panicSolution = Organs(image: UIImage(named: "stomach")!, description:  "There are several ways to cope with this illness, here's some tips on how you can cope with this illness.\n\n\u{2022} Don't assure you're about to have an attack\n When you feel a symptom, remember that the symptoms may be caused by generalized anxiety. So do regular breathing, and don't panic.\n\n\u{2022} You can't die from a panic attack\n It's very important to remember that panic attacks can't kill you. You can't die from it, it's important for you to accept that you have a panic attack and live your life.", titleOrgan: "Solution")
        panicOrganArray.append(panicSolution)
        
        illnessList.append(panicOrganArray)
        
    }
    
    private func setConstraint(){
        self.view.addSubview(self.middleView)
        self.view.addSubview(self.rightView)
        self.view.addSubview(self.leftView)
     
        self.middleView.addSubview(self.bodyImage)
        self.middleView.addSubview(self.depressionButton)
        self.middleView.addSubview(self.anxietyButton)
        self.middleView.addSubview(self.ptsdButton)
        self.middleView.addSubview(self.bipolarButton)
        self.middleView.addSubview(self.panicButton)
        self.rightView.addSubview(self.containerView)
        self.rightView.addSubview(self.mentrelyLabel)
        self.containerView.addSubview(titleLabel)
        self.containerView.addSubview(backButton)
        self.containerView.addSubview(organImage)
        self.containerView.addSubview(descTextView)
        self.containerView.addSubview(pageControl)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture(gesture:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.containerView.addGestureRecognizer(swipeRight)

        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture(gesture:)))
        swipeLeft.direction = UISwipeGestureRecognizer.Direction.left
        self.containerView.addGestureRecognizer(swipeLeft)
      
        let leftViewHeight = self.leftView.heightAnchor.constraint(equalToConstant: self.view.frame.height)
        leftViewHeight.identifier = "leftViewHeight"
        let leftViewWidth =  self.leftView.widthAnchor.constraint(equalToConstant: self.view.frame.width/10)
        leftViewWidth.identifier = "leftViewWidth"
       
        let organTop =  self.organImage.topAnchor.constraint(equalTo: self.containerView.topAnchor, constant: 75)
        organTop.identifier = "organTop"
        
        let organHeight =  self.organImage.heightAnchor.constraint(equalToConstant: 0)
        organHeight.identifier = "organHeight"
        
        let depressionButtonWidth = self.depressionButton.widthAnchor.constraint(equalToConstant: 145)
        depressionButtonWidth.identifier = "depressionButtonWidth"
        
        let anxietyButtonWidth = self.anxietyButton.widthAnchor.constraint(equalToConstant: 145)
        anxietyButtonWidth.identifier = "anxietyButtonWidth"
        
        let ptsdButtonWidth = self.ptsdButton.widthAnchor.constraint(equalToConstant: 145)
        ptsdButtonWidth.identifier = "ptsdButtonWidth"
        
        let bipolarButtonWidth = self.bipolarButton.widthAnchor.constraint(equalToConstant: 145)
        bipolarButtonWidth.identifier = "bipolarButtonWidth"
        
        let panicButtonWidth = self.panicButton.widthAnchor.constraint(equalToConstant: 145)
        panicButtonWidth.identifier = "panicButtonWidth"
       
       NSLayoutConstraint.activate([
        leftViewHeight,
        leftViewHeight,
        self.leftView.topAnchor.constraint(equalTo: self.view.topAnchor),
        self.leftView.leftAnchor.constraint(equalTo: self.view.leftAnchor),
        
        self.middleView.heightAnchor.constraint(equalToConstant: self.view.frame.height),
        self.middleView.widthAnchor.constraint(equalToConstant: self.view.frame.width/2),
        self.middleView.topAnchor.constraint(equalTo: self.view.topAnchor),
        self.middleView.leftAnchor.constraint(equalTo: self.leftView.rightAnchor),
        
        self.rightView.heightAnchor.constraint(equalToConstant: self.view.frame.height),
        self.rightView.widthAnchor.constraint(equalToConstant: self.view.frame.width - (self.leftView.frame.width + self.middleView.frame.width )),
        self.rightView.leftAnchor.constraint(equalTo: self.middleView.rightAnchor),
        self.rightView.topAnchor.constraint(equalTo: self.view.topAnchor),
        
        self.mentrelyLabel.topAnchor.constraint(equalTo: self.rightView.topAnchor, constant: 50),
        self.mentrelyLabel.rightAnchor.constraint(equalTo: self.rightView.rightAnchor),
        self.mentrelyLabel.bottomAnchor.constraint(equalTo: self.containerView.topAnchor),
        self.mentrelyLabel.centerXAnchor.constraint(equalTo: self.rightView.centerXAnchor),
        self.mentrelyLabel.leftAnchor.constraint(equalTo: self.rightView.leftAnchor,constant: 10),

        self.containerView.rightAnchor.constraint(equalTo: self.view.rightAnchor),
        self.containerView.topAnchor.constraint(equalTo: self.mentrelyLabel.topAnchor, constant: 125),
        self.containerView.leftAnchor.constraint(equalTo: self.rightView.leftAnchor, constant: 0),
        self.containerView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor,constant: -25),
        
        self.backButton.topAnchor.constraint(equalTo: self.containerView.topAnchor, constant: 20),
        self.backButton.widthAnchor.constraint(equalToConstant: 50),
        self.backButton.leftAnchor.constraint(equalTo: self.containerView.leftAnchor, constant: 30),
        
        self.titleLabel.topAnchor.constraint(equalTo: self.containerView.topAnchor, constant: 20),
        self.titleLabel.centerXAnchor.constraint(equalTo: self.containerView.centerXAnchor),
        self.titleLabel.heightAnchor.constraint(equalToConstant: 50),
        
        organTop,
        organHeight,
        self.organImage.leftAnchor.constraint(equalTo: self.containerView.leftAnchor, constant: 100),
        self.organImage.rightAnchor.constraint(equalTo: self.containerView.rightAnchor, constant: -100),
        self.organImage.centerXAnchor.constraint(equalTo: self.containerView.centerXAnchor),
        
        depressionButtonWidth,
        self.depressionButton.leftAnchor.constraint(equalTo: self.leftView.leftAnchor, constant: 0),
        self.depressionButton.topAnchor.constraint(equalTo: self.leftView.topAnchor, constant: 150),
        
        self.descTextView.topAnchor.constraint(equalTo: self.organImage.bottomAnchor, constant: 20),
        self.descTextView.leftAnchor.constraint(equalTo: self.containerView.leftAnchor, constant: 30),
        self.descTextView.rightAnchor.constraint(equalTo: self.containerView.rightAnchor, constant: -30),
        self.descTextView.bottomAnchor.constraint(equalTo: self.containerView.bottomAnchor, constant: -40),
        self.descTextView.centerXAnchor.constraint(equalTo: self.containerView.centerXAnchor),
        
        self.pageControl.topAnchor.constraint(equalTo: self.descTextView.bottomAnchor, constant: 10),
        self.pageControl.centerXAnchor.constraint(equalTo: self.containerView.centerXAnchor),
        self.pageControl.leftAnchor.constraint(equalTo: self.containerView.leftAnchor, constant: 100),
        self.pageControl.rightAnchor.constraint(equalTo: self.containerView.rightAnchor, constant: -100),
        self.pageControl.heightAnchor.constraint(equalToConstant: 10),
        
        anxietyButtonWidth,
        self.anxietyButton.leftAnchor.constraint(equalTo: self.leftView.leftAnchor, constant: 0),
        self.anxietyButton.topAnchor.constraint(equalTo: self.depressionButton.topAnchor, constant: 100),
            
        ptsdButtonWidth,
        self.ptsdButton.leftAnchor.constraint(equalTo: self.leftView.leftAnchor, constant: 0),
        self.ptsdButton.topAnchor.constraint(equalTo: self.anxietyButton.topAnchor, constant: 100),

        bipolarButtonWidth,
        self.bipolarButton.leftAnchor.constraint(equalTo: self.leftView.leftAnchor, constant: 0),
        self.bipolarButton.topAnchor.constraint(equalTo: self.ptsdButton.topAnchor, constant: 100),
    
        panicButtonWidth,
        self.panicButton.leftAnchor.constraint(equalTo: self.leftView.leftAnchor, constant: 0),
        self.panicButton.topAnchor.constraint(equalTo: self.bipolarButton.topAnchor, constant: 100),
        
        self.bodyImage.centerXAnchor.constraint(equalTo: self.middleView.centerXAnchor),
        self.bodyImage.centerYAnchor.constraint(equalTo: self.middleView.centerYAnchor),
        self.bodyImage.bottomAnchor.constraint(equalTo: self.middleView.bottomAnchor, constant: 0),
        self.bodyImage.leftAnchor.constraint(equalTo: self.leftView.leftAnchor, constant: 0),
        self.bodyImage.rightAnchor.constraint(equalTo: self.middleView.rightAnchor, constant: 0),

       ])
     }
    
    private func hideOrganImage() {
        let constraint = organImage.constraintWith(identifier: "organHeight")
        UIView.animate(withDuration: 1) {
            constraint?.constant    = 1
            self.view.layoutIfNeeded()
        }
    }
    
    private func showOrganImage() {
        let constraint = organImage.constraintWith(identifier: "organHeight")
        UIView.animate(withDuration: 1) {
            constraint?.constant    = 150
            self.view.layoutIfNeeded()
        }
    }
    
    @objc private func respondToSwipeGesture(gesture: UIGestureRecognizer){
        if illnessTypeVar != .mainMenu {
            if let swipeGesture = gesture as? UISwipeGestureRecognizer{
                switch swipeGesture.direction{
                    case UISwipeGestureRecognizer.Direction.left:
                        if self.organIndex != self.illnessList[self.indexSelected].count - 1 {
                            organIndex += 1
                            self.changeOrganUI()
                            if organIndex == self.illnessList[self.indexSelected].count - 1 {
                                hideOrganImage()
                            }else {
                                showOrganImage()
                            }
                        }else {
                            hideOrganImage()
                        }
                        pageControl.currentPage = organIndex
                    case UISwipeGestureRecognizer.Direction.right:
                        if self.organIndex != 0 {
                            organIndex -= 1
                            self.changeOrganUI()
                            if organIndex == 0 {
                                hideOrganImage()
                            }else {
                                showOrganImage()
                            }
                        }else {
                            hideOrganImage()
                        }
                        pageControl.currentPage = organIndex
                    default:
                        break
                }
            }
        }
    }
    
    private func changeOrganUI() {
        UIView.transition(with: descTextView,
                          duration: 0.35,
                          options: .transitionCrossDissolve,
                          animations: {
                                self.descTextView.text = self.illnessList[self.indexSelected][self.organIndex].description
        },completion: nil)
        
        UIView.transition(with: titleLabel,
                          duration: 0.35,
                          options: .transitionCrossDissolve,
                          animations: {
                                self.titleLabel.text = self.illnessList[self.indexSelected][self.organIndex].titleOrgan
        },completion: nil)
        
        UIView.transition(with: organImage,
                          duration: 0.25,
                          options: .transitionCrossDissolve,
                          animations: {
                                self.organImage.image  = self.illnessList[self.indexSelected][self.organIndex].image
        },completion: nil)
    }
    
    private func triggerUIUpdate() {
        switch illnessTypeVar {
        case .depression:
            indexSelected = 0
            setupConstraintAndAlpha(1, 200, 125, 105, 105, 105, 1.0, 0.4, 0.4, 0.4, 0.4, 1, 1)
            setupDefaultUI()
        case .anxiety:
            indexSelected = 1
            setupConstraintAndAlpha(1, 145, 200, 105, 105, 105, 0.4, 1.0, 0.4, 0.4, 0.4, 1, 1)
            setupDefaultUI()
        case .ptsd:
            indexSelected = 2
            setupConstraintAndAlpha(1, 145, 125, 200, 105, 105, 0.4, 0.4, 1.0, 0.4, 0.4, 1, 1)
            setupDefaultUI()
        case .bipolar:
            indexSelected = 3
            setupConstraintAndAlpha(1, 145, 125, 105, 200, 105, 0.4, 0.4, 0.4, 1.0, 0.4, 1, 1)
            setupDefaultUI()
        case .panic:
            indexSelected = 4
            setupConstraintAndAlpha(1, 145, 125, 105, 105, 200, 0.4, 0.4, 0.4, 0.4, 1.0, 1, 1)
            setupDefaultUI()
        case .mainMenu:
            backButton.isEnabled = false
            UIView.transition(with: bodyImage,
                                duration: 0.35,
                                options: .transitionCrossDissolve,
                                animations: {
                self.bodyImage.image = UIImage(named: "fullBody")!
            },completion: nil)
            UIView.transition(with: descTextView,
                              duration: 0.35,
                              options: .transitionCrossDissolve,
                              animations: {
                self.descTextView.text = self.introText
            },completion: nil)
            UIView.transition(with: titleLabel,
                              duration: 0.35,
                              options: .transitionCrossDissolve,
                              animations: {
                self.titleLabel.text = self.introTitleText
            },completion: nil)
            indexSelected = -1
            organIndex    = -1
            setupConstraintAndAlpha(1, 145, 145, 145, 145, 145, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0)
        }
    }
    
    private func setupConstraintAndAlpha (_ organConstant : CGFloat, _ depressionConstant : CGFloat, _ anxietyConstant : CGFloat, _ ptsdConstant : CGFloat,
                                          _ bipolarConstant : CGFloat, _ panicConstant : CGFloat, _ depressionAlpha : Double, _ anxietyAlpha : Double, _ ptsdAlpha : Double, _ bipolarAlpha : Double, _ panicAlpha : Double, _ pageControlAlpha : Double, _ backButtonAlpha : Double) {
        
        let constraint = organImage.constraintWith(identifier: "organHeight")
        let constraintDW = depressionButton.constraintWith(identifier: "depressionButtonWidth")
        let constraintAW = anxietyButton.constraintWith(identifier: "anxietyButtonWidth")
        let constraintPW = ptsdButton.constraintWith(identifier: "ptsdButtonWidth")
        let constraintBW = bipolarButton.constraintWith(identifier: "bipolarButtonWidth")
        let constraintPaW = panicButton.constraintWith(identifier: "panicButtonWidth")
        
        UIView.animate(withDuration: 1) {
            constraint?.constant    = organConstant
            constraintDW?.constant  = depressionConstant
            constraintAW?.constant  = anxietyConstant
            constraintPW?.constant  = ptsdConstant
            constraintBW?.constant  = bipolarConstant
            constraintPaW?.constant = panicConstant
            self.depressionButton.alpha = depressionAlpha
            self.anxietyButton.alpha    = anxietyAlpha
            self.ptsdButton.alpha       = ptsdAlpha
            self.bipolarButton.alpha    = bipolarAlpha
            self.panicButton.alpha      = panicAlpha
            self.pageControl.alpha = pageControlAlpha
            self.backButton.alpha  = backButtonAlpha
            self.view.layoutIfNeeded()
        }
    }
    
    private func setupDefaultUI() {
        if illnessTypeVar == .mainMenu {
            print("mainMenu")
            UIView.transition(with: bodyImage,
                                duration: 0.35,
                                options: .transitionCrossDissolve,
                                animations: {
                self.bodyImage.image = UIImage(named: "fullbody")!
            },completion: nil)
        }else {
            if illnessTypeVar == .depression || illnessTypeVar == .bipolar || illnessTypeVar == .panic {
                UIView.transition(with: bodyImage,
                                    duration: 0.35,
                                    options: .transitionCrossDissolve,
                                    animations: {
                    self.bodyImage.image = UIImage(named: "depressionBody")!
                },completion: nil)
            }else if illnessTypeVar == .anxiety {
                UIView.transition(with: bodyImage,
                                    duration: 0.35,
                                    options: .transitionCrossDissolve,
                                    animations: {
                    self.bodyImage.image = UIImage(named: "anxietyBody")!
                },completion: nil)
            }else if illnessTypeVar == .ptsd {
                UIView.transition(with: bodyImage,
                                    duration: 0.35,
                                    options: .transitionCrossDissolve,
                                    animations: {
                    self.bodyImage.image = UIImage(named: "ptsdBody")!
                },completion: nil)
            }
        }
            
        backButton.isEnabled = true
        organIndex    = 0
        UIView.transition(with: descTextView,
                          duration: 0.35,
                          options: .transitionCrossDissolve,
                          animations: {
                                self.descTextView.text = self.illnessList[self.indexSelected][self.organIndex].description
        },completion: nil)
        UIView.transition(with: titleLabel,
                          duration: 0.35,
                          options: .transitionCrossDissolve,
                          animations: {
                                self.titleLabel.text = self.illnessList[self.indexSelected][self.organIndex].titleOrgan
        },completion: nil)
        pageControl.numberOfPages = self.illnessList[indexSelected].count
        pageControl.currentPage   = self.organIndex
    }
    
    @objc func responseButton(_ sender: UIButton){
        switch sender.tag {
        case 0:
            illnessTypeVar = .depression
        case 1:
            illnessTypeVar = .anxiety
        case 2:
            illnessTypeVar = .ptsd
        case 3:
            illnessTypeVar = .bipolar
        case 4:
            illnessTypeVar = .panic
        case 5:
            illnessTypeVar = .mainMenu
        default:
            break
        }
        triggerUIUpdate()
    }
}
